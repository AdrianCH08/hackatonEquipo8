using System.Collections;
using System.Collections.Generic;
//using UnityEngine;

//public class StarSpawner : MonoBehaviour
//{
//    public GameObject starPrefab;
//    public float spawnRate = 1f;
//    public float minY = -4f;
//    public float maxY = 4f;

//    void Start()
//    {
//        // Start spawning stars at regular intervals
//        InvokeRepeating("SpawnStar", 1f, spawnRate);
//    }

//    void SpawnStar()
//    {
//        // Define the spawn position at the right edge of the screen
//        Vector2 spawnPosition = new Vector2(Camera.main.orthographicSize * Camera.main.aspect + 1, Random.Range(minY, maxY));
//        // Instantiate the star at the spawn position
//        Instantiate(starPrefab, spawnPosition, Quaternion.identity);
//    }
//}
using UnityEngine;


public class StarSpawner : MonoBehaviour
{
    public GameObject starPrefab;
    public float initialSpawnRate = 1f;
    public float minSpawnRate = 0.1f;  // Minimum spawn rate to avoid spawning too quickly
    public float spawnRateDecreaseInterval = 10f;  // Interval to decrease spawn rate
    public float spawnRateDecreaseAmount = 0.1f;  // Amount to decrease spawn rate each interval
    public float minY = -4f;
    public float maxY = 4f;
    public float stepY = 0.5f; // Distance between each step
    private bool ascending = true;
    private float currentY;
    private float currentSpawnRate;

    void Start()
    {
        currentY = minY;
        currentSpawnRate = initialSpawnRate;
        StartCoroutine(SpawnStar());
        StartCoroutine(DecreaseSpawnRate());
    }

    IEnumerator SpawnStar()
    {
        while (true)
        {
            // Define the spawn position at the right edge of the screen
            Vector2 spawnPosition = new Vector2(Camera.main.orthographicSize * Camera.main.aspect + 1, currentY);
            // Instantiate the star at the spawn position
            Instantiate(starPrefab, spawnPosition, Quaternion.identity);

            // Update currentY for the next star position
            if (ascending)
            {
                currentY += stepY;
                if (currentY > maxY)
                {
                    ascending = false;
                    currentY = maxY;
                }
            }
            else
            {
                currentY -= stepY;
                if (currentY < minY)
                {
                    ascending = true;
                    currentY = minY;
                }
            }

            yield return new WaitForSeconds(currentSpawnRate);
        }
    }

    IEnumerator DecreaseSpawnRate()
    {
        while (true)
        {
            yield return new WaitForSeconds(spawnRateDecreaseInterval);

            if (currentSpawnRate > minSpawnRate)
            {
                currentSpawnRate -= spawnRateDecreaseAmount;
                if (currentSpawnRate < minSpawnRate)
                {
                    currentSpawnRate = minSpawnRate;
                }
            }
        }
    }
}


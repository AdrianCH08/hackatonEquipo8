using System.Collections;
using System.Collections.Generic;
using UnityEngine;
//using UnityEngine;

//public class PlayerController : MonoBehaviour
//{
//    public float velocity = 0.2f;
//    public float rotationSpeed = 0.2f;


//    private Rigidbody2D rb;

//    private void Start()
//    {
//        rb = GetComponent<Rigidbody2D>();
//    }

//    void Update()
//    {


//        if (Input.GetKey(KeyCode.UpArrow)) // Simulates exhaling
//        {
//            rb.velocity = Vector2.up * velocity;
//        }
//        else if (Input.GetKey(KeyCode.DownArrow)) // Simulates inhaling
//        {
//            rb.velocity = Vector2.down * velocity;
//        }
//    }
//    private void FixedUpdate()
//    {
//        transform.rotation = Quaternion.Euler(0, 0, rb.velocity.y * rotationSpeed);
//    }
//}


public class PlayerController : MonoBehaviour
{
    public float velocity = 0.2f;
    public float rotationSpeed = 0.2f;
    public float gravity = 2f; // Gravity force when not speaking

    private Rigidbody2D rb;
    private float sensitivity = 10f; // Adjusted sensitivity for noisy environment
    private float loudnessThreshold = 0.5f; // Adjusted threshold for detecting speaking

    private AudioClip microphoneClip;
    private bool microphoneInitialized = false;

    void Start()
    {
        rb = GetComponent<Rigidbody2D>();
        rb.gravityScale = 0; // Initially disable gravity
        InitializeMicrophone();
    }

    void InitializeMicrophone()
    {
        if (Microphone.devices.Length > 0)
        {
            microphoneClip = Microphone.Start(null, true, 10, 44100);
            microphoneInitialized = true;
        }
        else
        {
            Debug.LogWarning("No microphone found!");
        }
    }

    void Update()
    {
        HandleMicrophoneInput();

        if (Input.GetKey(KeyCode.UpArrow)) // Simulates exhaling
        {
            rb.velocity = Vector2.up * velocity;
        }
        else if (Input.GetKey(KeyCode.DownArrow)) // Simulates inhaling
        {
            rb.velocity = Vector2.down * velocity;
        }
    }

    void HandleMicrophoneInput()
    {
        if (microphoneInitialized)
        {
            float loudness = GetAveragedVolume();
            if (loudness > loudnessThreshold)
            {
                // Simulate exhaling when microphone input detected
                rb.velocity = Vector2.up * velocity;
                rb.gravityScale = 0; // Disable gravity
            }
            else
            {
                // Simulate inhaling (or no movement) when no microphone input
                rb.velocity = Vector2.zero;
                rb.gravityScale = gravity; // Enable gravity
            }
        }
    }

    float GetAveragedVolume()
    {
        float[] data = new float[256];
        float a = 0;
        microphoneClip.GetData(data, Microphone.GetPosition(null) - 256);
        foreach (float s in data)
        {
            a += Mathf.Abs(s);
        }
        return a / 256 * sensitivity;
    }

    private void FixedUpdate()
    {
        transform.rotation = Quaternion.Euler(0, 0, rb.velocity.y * rotationSpeed);
    }
}


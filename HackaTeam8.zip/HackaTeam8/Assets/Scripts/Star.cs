using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Star : MonoBehaviour
{
    public float speed = 2f;  // Reduce this value to slow down the stars

    void Update()
    {
        // Move the star from right to left
        transform.Translate(Vector2.left * speed * Time.deltaTime);
    }

    void OnTriggerEnter2D(Collider2D other)
    {
        // Check if the star collides with the player
        if (other.CompareTag("Player"))
        {
            // Destroy the star
            Destroy(gameObject);
        }
    }
}
